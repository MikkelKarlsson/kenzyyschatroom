package com.example.msk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MskApplication {

    public static void main(String[] args) {
        SpringApplication.run(MskApplication.class, args);
    }

}
