package com.example.msk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MskApplicationTests {

    @Test
    void contextLoads() {
    }

}
